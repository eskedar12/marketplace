import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { listingsApi } from '../../api/listings.api.js';
import ListingGrid from '../../components/listings/ListingGrid.jsx';
import { CATEGORY_VISUALS } from '../../utils/categoryIcons.jsx';

const CITIES = [
  'Addis Ababa',
  'Adama',
  'Hawassa',
  'Bahir Dar',
  'Dire Dawa',
  'Mekelle',
  'Gondar',
  'Dessie',
  'Jimma',
];

const WHY_REGEBEYA = [
  {
    title: 'Safe Marketplace',
    body: 'Buy and sell with confidence.',
    bg: 'bg-emerald-50',
    iconBg: 'bg-emerald-500',
    icon: (
      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4" />
      </svg>
    ),
  },
  {
    title: 'Local Listings',
    body: 'Find items near you.',
    bg: 'bg-orange-50',
    iconBg: 'bg-mustard',
    icon: (
      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M17.66 16.66L13.4 20.9a2 2 0 01-2.83 0l-4.24-4.24a8 8 0 1111.31 0z" />
        <circle cx="12" cy="11" r="3" />
      </svg>
    ),
  },
  {
    title: 'Easy Communication',
    body: 'Connect directly with sellers.',
    bg: 'bg-blue-50',
    iconBg: 'bg-blue-500',
    icon: (
      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 11.5a8.5 8.5 0 01-8.5 8.5 8.6 8.6 0 01-3.6-.78L3 20l1.02-3.67A8.4 8.4 0 013 12.5 8.5 8.5 0 0111.5 4h.5a8.5 8.5 0 019 8v-.5z" />
      </svg>
    ),
  },
  {
    title: 'Trusted Sellers',
    body: 'Ratings help you buy safely.',
    bg: 'bg-amber-50',
    iconBg: 'bg-amber-400',
    icon: (
      <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 2.5l2.9 6.1 6.6.7-4.9 4.6 1.3 6.6L12 17.1l-5.9 3.4 1.3-6.6-4.9-4.6 6.6-.7z" />
      </svg>
    ),
  },
];

export default function Home() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [city, setCity] = useState('');

  const [recent, setRecent] = useState([]);
  const [recentLoading, setRecentLoading] = useState(true);

  useEffect(() => {
    listingsApi
      .search({ limit: 5, page: 1 })
      .then((res) => setRecent(res.data.items))
      .catch(() => {})
      .finally(() => setRecentLoading(false));
  }, []);

  function handleSearchSubmit(e) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (query) params.set('q', query);
    if (city) params.set('city', city);
    navigate(`/listings?${params.toString()}`);
  }

  return (
    <div className="w-full">
      {/* 1. Hero */}
      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1686143293611-85158a1a9370?auto=format&fit=crop&w=1740&q=80')" }}
        />
        {/* Dark wash so white headline/search text stays readable over the photo */}
        <div className="absolute inset-0 bg-gradient-to-b from-juniper-dark/80 via-juniper-dark/60 to-juniper-dark/85" />

        <div className="relative max-w-4xl mx-auto z-10 px-4 py-20 md:py-28 text-center">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight leading-tight mb-4 font-display">
            Every <span className="text-mustard">kinda</span> thing,
            <br />
            for every <span className="text-mustard">kinda</span> person.
          </h1>

          <form
            onSubmit={handleSearchSubmit}
            className="max-w-2xl mx-auto bg-white p-2 rounded-2xl md:rounded-full shadow-2xl flex flex-col md:flex-row items-stretch gap-2 mt-10"
          >
            <div className="flex items-center gap-2 px-4 py-2.5 md:py-0 border-b md:border-b-0 md:border-r border-line flex-shrink-0">
              <svg className="w-[18px] h-[18px] text-ink/40 flex-shrink-0" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M17.66 16.66L13.4 20.9a2 2 0 01-2.83 0l-4.24-4.24a8 8 0 1111.31 0z" />
                <circle cx="12" cy="11" r="3" />
              </svg>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="bg-transparent text-sm font-medium text-ink font-body focus:outline-none cursor-pointer pr-2"
              >
                <option value="">All Ethiopia</option>
                {CITIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div className="flex-1 flex items-center gap-2 px-4 py-2.5 md:py-0">
              <svg className="w-[18px] h-[18px] text-ink/30 flex-shrink-0" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search for anything..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full bg-transparent text-sm text-ink font-body focus:outline-none placeholder-ink/40"
              />
            </div>

            <button
              type="submit"
              className="bg-mustard hover:bg-mustard-dark text-white font-display font-bold text-sm px-8 py-3 rounded-xl md:rounded-full transition-colors"
            >
              Search
            </button>
          </form>
        </div>
      </section>

      {/* 2. Browse by Category */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
        <h2 className="font-display font-extrabold text-2xl text-ink mb-8">Browse by Category</h2>

        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
          {CATEGORY_VISUALS.map((cat) => (
            <Link
              key={cat.name}
              to={`/category/${cat.dbSlug}`}
              className="flex flex-col items-center text-center gap-2.5 p-4 rounded-2xl border border-line bg-white hover:shadow-md hover:-translate-y-0.5 transition-all"
            >
              <span className={`w-14 h-14 rounded-full flex items-center justify-center ${cat.bg} ${cat.fg}`}>
                {cat.icon('w-6 h-6')}
              </span>
              <span className="font-body font-medium text-sm text-ink leading-tight">{cat.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* 3. Recently Listed */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-6">
        <div className="flex items-center justify-between mb-8">
          <h2 className="font-display font-extrabold text-2xl text-ink">Recently Listed</h2>
          <Link to="/listings" className="text-sm font-body font-semibold text-mustard hover:text-mustard-dark transition-colors">
            View All &rarr;
          </Link>
        </div>

        <ListingGrid listings={recent} loading={recentLoading} />
      </section>

      {/* 4. Why ReGebeya */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <h2 className="font-display font-extrabold text-2xl text-ink text-center mb-8">Why ReGebeya?</h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {WHY_REGEBEYA.map((item) => (
            <div key={item.title} className={`rounded-2xl p-6 text-center ${item.bg}`}>
              <span className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 ${item.iconBg}`}>
                {item.icon}
              </span>
              <h3 className="font-display font-bold text-sm text-ink mb-1">{item.title}</h3>
              <p className="text-xs font-body text-ink/60">{item.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 5. CTA banner */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-16">
        <div className="rounded-2xl bg-gradient-to-r from-orange-50 to-amber-50 border border-orange-100 px-6 sm:px-10 py-10 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <span className="w-16 h-16 rounded-2xl bg-white shadow-sm flex items-center justify-center text-3xl flex-shrink-0">
              📦
            </span>
            <div>
              <p className="font-display font-extrabold text-lg sm:text-xl text-ink">
                Have something you don't need anymore?
              </p>
              <p className="font-display font-extrabold text-lg sm:text-xl text-mustard">Give it a new home.</p>
            </div>
          </div>

          <Link
            to="/sell"
            className="flex items-center gap-1.5 bg-mustard hover:bg-mustard-dark text-white font-display font-bold text-sm px-6 py-3 rounded-xl transition-colors flex-shrink-0"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Sell an Item
          </Link>
        </div>
      </section>
    </div>
  );
}
